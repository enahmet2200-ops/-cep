import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(SantiyeCepApp());
}

class SantiyeCepApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ŞantiyeCep',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.amber,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: AnaSayfaFirestore(),
    );
  }
}

// Model: İş İlanı Yapısı
class IsIlani {
  final String baslik;
  final String kategori;
  final String konum;
  final String yevmiye;
  final String tarih;

  IsIlani({required this.baslik, required this.kategori, required this.konum, required this.yevmiye, required this.tarih});

  factory IsIlani.fromMap(Map<String, dynamic> map) {
    return IsIlani(
      baslik: map['baslik'] ?? '',
      kategori: map['kategori'] ?? '',
      konum: map['konum'] ?? '',
      yevmiye: map['yevmiye'] ?? '',
      tarih: map['tarih'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'baslik': baslik,
      'kategori': kategori,
      'konum': konum,
      'yevmiye': yevmiye,
      'tarih': tarih,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }
}

// Ana Sayfa: Firestore stream kullanan versiyon
class AnaSayfaFirestore extends StatefulWidget {
  @override
  _AnaSayfaFirestoreState createState() => _AnaSayfaFirestoreState();
}

class _AnaSayfaFirestoreState extends State<AnaSayfaFirestore> {
  final CollectionReference ilanRef = FirebaseFirestore.instance.collection('ilanlar');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ŞantiyeCep", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(icon: Icon(Icons.notifications), onPressed: () {}),
        ],
      ),
      drawer: Drawer(), // Menü buraya gelecek
      body: Column(
        children: [
          // Arama Çubuğu
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: "İş veya usta ara...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (q) {
                // Basit: arama işlevi eklemek istersen burada filtre uygula
              },
            ),
          ),
          // İlan Listesi - StreamBuilder ile gerçek zamanlı
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: ilanRef.orderBy('createdAt', descending: true).snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) return Center(child: Text('Bir hata oluştu'));
                if (snapshot.connectionState == ConnectionState.waiting) return Center(child: CircularProgressIndicator());

                final docs = snapshot.data!.docs;
                if (docs.isEmpty) return Center(child: Text('Henüz ilan yok'));

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    final ilan = IsIlani.fromMap(data);
                    return IsKarti(ilan: ilan);
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => IlanVerSayfasi()));
        },
        label: Text("İlan Ver"),
        icon: Icon(Icons.add),
        backgroundColor: Colors.amber,
      ),
    );
  }
}

// İlan Kartı Tasarımı (aynı)
class IsKarti extends StatelessWidget {
  final IsIlani ilan;
  IsKarti({required this.ilan});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        contentPadding: EdgeInsets.all(15),
        leading: CircleAvatar(
          backgroundColor: Colors.amber[100],
          child: Icon(Icons.construction, color: Colors.amber[900]),
        ),
        title: Text(ilan.baslik, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 5),
            Text("${ilan.kategori} | ${ilan.konum}"),
            SizedBox(height: 5),
            Text("Yevmiye: ${ilan.yevmiye}", style: TextStyle(color: Colors.green[700], fontWeight: FontWeight.w600)),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.arrow_forward_ios, size: 16),
            SizedBox(height: 5),
            Text(ilan.tarih, style: TextStyle(fontSize: 10, color: Colors.grey)),
          ],
        ),
        onTap: () {
          // İlan detayına git
        },
      ),
    );
  }
}

// İlan Verme Sayfası -> Firestore'a kaydeder
class IlanVerSayfasi extends StatefulWidget {
  @override
  _IlanVerSayfasiState createState() => _IlanVerSayfasiState();
}

class _IlanVerSayfasiState extends State<IlanVerSayfasi> {
  final _baslikCtrl = TextEditingController();
  final _kategoriCtrl = TextEditingController();
  final _konumCtrl = TextEditingController();
  final _yevmiyeCtrl = TextEditingController();
  final _detayCtrl = TextEditingController();

  final CollectionReference ilanRef = FirebaseFirestore.instance.collection('ilanlar');

  @override
  void dispose() {
    _baslikCtrl.dispose();
    _kategoriCtrl.dispose();
    _konumCtrl.dispose();
    _yevmiyeCtrl.dispose();
    _detayCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitIlan() async {
    final ilan = IsIlani(
      baslik: _baslikCtrl.text.trim(),
      kategori: _kategoriCtrl.text.trim(),
      konum: _konumCtrl.text.trim(),
      yevmiye: _yevmiyeCtrl.text.trim(),
      tarih: 'Şimdi',
    );

    if (ilan.baslik.isEmpty || ilan.kategori.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Lütfen başlık ve kategori girin")));
      return;
    }

    await ilanRef.add({
      ...ilan.toMap(),
      'detay': _detayCtrl.text.trim(),
    });

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("İlan başarıyla yayınlandı!")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Yeni İlan Oluştur")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: _baslikCtrl, decoration: InputDecoration(labelText: "İş Başlığı (Örn: Acil Duvar Ustası)")),
              SizedBox(height: 15),
              TextField(controller: _kategoriCtrl, decoration: InputDecoration(labelText: "Kategori (Sıva, Boya, Elektrik...)")),
              SizedBox(height: 15),
              TextField(controller: _konumCtrl, decoration: InputDecoration(labelText: "Şehir / İlçe")),
              SizedBox(height: 15),
              TextField(controller: _yevmiyeCtrl, decoration: InputDecoration(labelText: "Günlük Yevmiye (TL)"), keyboardType: TextInputType.number),
              SizedBox(height: 15),
              TextField(controller: _detayCtrl, decoration: InputDecoration(labelText: "İş Detayı ve Aranan Özellikler"), maxLines: 3),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: _submitIlan,
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 15),
                  child: Center(child: Text("İLAN YAYINLA", style: TextStyle(fontSize: 18))),
                ),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.amber),
              )
            ],
          ),
        ),
      ),
    );
  }
}